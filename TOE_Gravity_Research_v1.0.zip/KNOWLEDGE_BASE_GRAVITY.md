# Knowledge Base: Gravity Research in FIN Theory
**Date:** 2025-12-09
**Status:** Review for QW-736 Proposal

## 1. Overview of Previous Approaches
The quest for "Emergent Gravity" has followed three main paradigms:

### A. The "Flow Model" (Hydrodynamic)
*   **Core Idea:** Space flows towards mass like a river. Gravity is the drag force of this flow.
*   **Key Scripts:** `QW-563` to `QW-567`.
*   **Mechanism:** Assumed a propagator $H \sim 1/r$ (Green's function) or a velocity field $v \sim 1/\sqrt{r}$.
*   **Results:**
    *   **Success:** Reproduced Time Dilation (Clock Lag), Stable Orbits, Frame Dragging.
    *   **Weakness:** The input velocity field or propagator $1/r$ was often assumed, not derived from lattice topology.
    *   **Score:** 🟢 Qualitative Success, 🔴 Quantitative Tautology (Input $\approx$ Output).

### B. The "Force Model" (Newtonian/MOND)
*   **Core Idea:** Force is the gradient of Defect Energy.
*   **Key Scripts:** `QW-722`, `QW-675`, `QW-588`.
*   **Mechanism:** Defined mass as topological defect. Defined Interaction Kernel $K(d)$. Calculated $E = \sum K(d_{ij})$ and $F = -\nabla E$.
*   **Results:**
    *   **Success:** Unified Mass Spectrum (QW-726), MOND Galactic Rotation (QW-588).
    *   **Weakness (The "Scam"):** The Kernel $K(d) \propto 1/(1+\beta d)$ was hardcoded to be hyperbolic (Newtonian-like).
    *   **Defense:** Theoretical paper `RAPORT_DERIWACJI_JADRA.md` argues that $K(d)$ emerges from summing fractal paths ($e^{-\alpha d} \to 1/r$), but this was derived analytically, not simulated in the scripts.

### C. The "Entropic/Path Integral" Model
*   **Core Idea:** Geodesics emerge from entropy maximization on a graph.
*   **Key Script:** `QW-580`.
*   **Mechanism:** Monte Carlo random walk with "Optical Index" $n(r)$.
*   **Results:**
    *   **Success:** Visualized geodesic bunching.
    *   **Weakness:** The Optical Index $n(r) = 1 + 2GM/r$ was manually inserted.

## 2. The Tautology Problem (Gap Analysis)
The user's critique is valid: **"Grawitacja wychodzi, bo ręcznie wstawiłeś 1/r²"**.
In all cases, the $1/r$ scaling was either:
1.  **Explicitly inserted** into the Force/Kernel formula (QW-722, QW-675).
2.  **Implicitly inserted** via an "Optical Index" or "Velocity Field" (QW-580, QW-563).
3.  **Theoretically claimed** (Path Summation) but not simulated (QW-564).

**Missing Link:**
A simulation where we input **ONLY** local topology (Nearest Neighbors) and **SEE** the $1/r$ potential emerge as the Green's Function of the Laplacian, without explicitly writing mathematical functions like `1/r` or `sqrt`.

## 3. Conclusions for QW-736 (New Study)
To answer the critique, QW-736 must:
*   **Prohibit** any function `f(r) = 1/r`.
*   **Use** only Adjacency Matrix $A_{ij}$ (Local Hopping).
*   **Compute** diffusion/propagator numerically ($G = L^{-1}$).
*   **Verify** if $G(r)$ naturally decays as $1/r$ in 3D.
*   **Hypothesis:** The "Laws of Physics" (specifically Poisson Equ. $\nabla^2 \phi = \rho$) are emergent properties of large number statistics on networks (Law of Large Numbers applied to Topology).
