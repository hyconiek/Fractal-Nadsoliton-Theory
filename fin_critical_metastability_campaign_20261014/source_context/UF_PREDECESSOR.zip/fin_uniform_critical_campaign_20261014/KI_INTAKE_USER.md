**# Intake of FIN kinetic invariants KI-001–KI-005**



Date: 2026-10-14. Baseline: \`cf1bf9ae\` plus the existing uncommitted SF intake,

next KI plan and SF additions to AGENTS.md. Those additions are preserved.

Source: [HANDOFF.md]\(../fin_kinetic_invariants_campaign_20261014/HANDOFF.md).

Predecessor: [SF intake]\(../fin_stochastic_fold_closure_review_20261014/INTAKE_20261014.md).

Plan: [KI plan]\(../FIN_KINETIC_INVARIANTS_NEXT_CHAIN_20261014.md).



**## Verdict**



**\*\*ACCEPT_SCOPED_THREE_KINETIC_FOLD_INVARIANCE_AND_THERMAL_READOUT_TRANSFER.\*\***



The three explicitly declared reversible rules share the same prepared,

compact-stopped critical law after their derived time conversion. The actual

kinetic coordinate and the thermal readout coincide asymptotically in this

scope, not at finite N. This is conditional analytical mathematics using the

inherited exact fold/input/backend and admitted SF boundary completion.

It is not a theorem for arbitrary kinetics, an unprepared equilibrium process,

peer review, formal proof-assistant verification or a physical-source result.



**## Provenance and replay**



All **\*\*72/72\*\*** source manifest entries, **\*\*8/8\*\*** source-input entries and **\*\*37/37\*\***

task-input entries agree. The source clean-replay report says71 entries: the

current final manifest contains72, including that report itself. Record the

actual manifest rather than silently copying the earlier count.



All **\*\*61\*\*** file members of the embedded SF archive match the local original

SF package. The archive contains the original SF proof, not the later intake's

explicit joint-clock completion as original executor evidence. Here that

completion is available locally, independently read and hash-bound as a

necessary inherited premise. No remote checkout or historical access is attested.



The attached KI plan agrees after Markdown escaping/emphasis, HTML entities

and whitespace normalization, not as identical bytes. Bundled theory_core.py

matches the earlier TH producer; bundled E04 contract matches its repo input.

Neither byte identity derives the kernel or fundamental kinetic choice.



The existing SF review's12-entry manifest and all7 saved verification inputs

remain unchanged. Its exact fold/spectral binding and stopped-law completion

are reused; no root census or large-N campaign is rerun.



Four scripts ran in a temporary copy: package check **\*\*before\*\*** writers,

kinetic_analysis, local_regularities and independent_verify. Source flags pass

**\*\*41/41\*\***. Recomputed mobilities drift by at most about \`3.11e-15\`; byte

identity of each regenerated output is recorded in [verification.json]\(verification.json).

\`build_reports.py\` and \`finalize.py\` were inspected, not run: they rewrite

status documents/manifests, and the latter writes an archive to historical \`/mnt/data\`.



Source checks have limitations: the "positive Hess remaining" residual subtracts

the same minimum from itself; the "fast eigen" flags actually repeat a

semidefiniteness check of K; the g0 flags compare stored constants. Constructing

\`J=-KH\` and then measuring \`J+KH\` also does not check the true drift derivative.

Therefore41/41 flags are not41 independent scientific proofs.



The intake [verifier]\(verify_intake.py) passes **\*\*46 bounded checks\*\***, including

strict Hessian/mobility positivity, the derivative of actual flux drift, a

different tangent/fast basis and Kronecker Lyapunov solve, nonlinear Onsager

identity, actual g0 rates,396 finite count detailed-balance cases, and direct

finite-jump \`L(V^2)=2V LV+sum rate\*(Delta V)^2\`. It rejects the unmatched Barker

clock. These checks corroborate arithmetic; the stochastic estimates are

accepted through the separate analytic arguments, not sampling or flags.



**## Admission by task**



**### KI-001 — thermodynamic matching**



Accept the constrained Hessian congruence: one null and ten positive occupation

directions, not equality of ambient Euclidean Hessian eigenvalues. Accept

\`a_F=a\` and \`b_F=b\` in the exact inherited r/v normalization, with constant

covectors removed on the occupation tangent. Transverse elimination preserves

the leading mixed-linear/cubic coefficients, not an exactly cubic full energy.

Existing primal/dual and fold inputs remain reused results.



**### KI-002 — reversible mobility and clocks**



Accept finite-N detailed balance for symmetric constant-diagonal A under the

exact declared LOO HB, MET \`1/12\`, and BAR \`2/12\` rules. Self-events do not

change the off-diagonal generator. The Barker factor2 is the explicitly

frozen E04 g0 convention, not the different historical safe_seed convention.



Accept the exact interior logarithmic-mean mobility representation

\`b=-K(p,g)grad F\`. At equilibrium only, \`J=-K_f H_F\` and \`D_f=2K_f\`.

Do not extend \`D=2K\` to every nonequilibrium occupation. Positivity/inverses

refer to the eleven-dimensional normalized tangent. The effective soft

mobility and left covector follow from the supplied rates:



&#x20;   m_K=[r^T K_f,T^(-1)r]^(-1),

&#x20;   ell_K^T=m_K r^T K_f,T^(-1).



HB recovers \`m_HB=g_f\` analytically. Nominal diagnostics independently reproduce:



\| Rule | m_K | m_K/m_HB |

\|---|---:|---:|

\| HB | 3.51564471684 | 1 |

\| MET | 0.460771172401 | 0.131063065103 |

\| BAR | 0.869409120506 | 0.247297207349 |



These are not outward intervals or measured clocks. At fixed A the ratios

distinguish the frozen kinetic rules; they also depend on the equilibrium

kernel/fold and are not interaction-independent invariants.



**### KI-003 — local process and same-observable limit**



Accept the MET regularity gate for these positive interior rates. The positive

edge logarithmic mean is smooth as a function of its two arguments, hence its

composition with the Lipschitz intensities is locally Lipschitz. The constant

equilibrium force is annihilated by K, and the soft Hessian force is zero on

the tangent. The kink correction therefore has the paid mixed/cubic remainder,

not a new leading quadratic soft term. No false C3 microscopic rate premise

is needed; no conclusion about arbitrary discontinuous/Hölder controls follows.



Accept the actual-jump second/fourth energy identities and local inequalities.

The fourth-moment smaller-threshold stopped Dynkin argument gives



&#x20;   P(sup_before_soft_exit ||w_N||>=epsilon N^(-1/3))

&#x20;     <=C epsilon^(-4) N^(-1/3),



in the rounded prepared scope. It retains the nonnegative exit value and

uses actual bounded jumps/total rate O(N). This is not a numeric finite-N

probability certificate with paid constants. The old second-moment tube alone

would not justify uniform thermal-observable transfer.



Thus the kinetic-coordinate limit is



&#x20;   dZ_K=-m_K(a lambda+b Z_K^2/2)ds+sqrt(2m_K)dB.



Its path identification reuses the admitted SF joint natural-filtration/UI/

stopped-clock proof with the actual control's bounded rate and bracket.

Accept the thermal readout under the same prepared scope, since its scaled

coordinate difference is uniformly o_P(1) before the outer local stop.



Two clarifications are binding. A bounded sequence of initial z0 does not

alone define a limiting law: use a fixed/convergent z0 or explicitly convergent

initial distributions. Also equality under **\*\*one common kinetic stop\*\*** does

not automatically prove equality of the two readouts' own first exits. Apply

the theorem and maximal comparison at an outer radius R'>R, then use Brownian

crossing continuity for each readout's inner R hit. This pays the native thermal

stop without applying an exit map circularly to an already frozen path.



Rounded starts have the required fourth moment. Broader mixtures retain

their explicit higher-moment/support/exceptional-event conditions; arbitrary

second-moment-only initial classes are not silently admitted.



**### KI-004 — honest class-level result**



Accept canonicalization with the fixed transformed preparations/boundaries

and \`d_K=c^2/(2m_K)\`. For the three paid control lanes it gives the same

\`dY=(kappa lambda-Y^2)d tau+dW\`. This proves the narrow kinetic-class

non-specificity of the inherited normalized eventual upper-exit number.

No new scalar digits are earned: the rational certificate is reused.



Eventual-side transfer uses the SF corollary for every fixed horizon, then

vanishing limiting survival tail, and irreducibility/accessibility of the

particular finite-N controls. It supplies neither a finite-N error rate nor

unbounded residence-time moment convergence or global phase switching.



The selected mobility ratio is meaningful under the frozen common g0 clock;

it disappears if final clocks are freely refitted. Accept

\`NO_NEW_FIN_SPECIFIC_EXIT_CONTRAST\`, not nature's selection of A7 or general

universality over kernels, ranks, all reversible rates or physical systems.



**### KI-005 — source-preserving handoff**



Accept reporting in the corrected scopes above. The proposed source AGENTS

patch is not applied verbatim; the repo guard records arithmetic limitations,

the local boundary/readout clarification and unchanged physical gates.



**## Next direction: fluctuations from a symmetric start, not another prepared fold**



KI completes a useful controller-robust local statistical mechanism, but its

initial law is still chosen near a particular fold. The next question should

test a different **\*\*existing\*\*** initial/reference state rather than collect

more normalized fold numbers.



The uniform parity instability \`g_c=12/Lambda6\` and pure-parity branch are

already known (report131/137); they are not new discoveries. The intake

propagates the accepted rational spectra to



&#x20;   g_c in [5.12342755139859,5.12342755139864],

&#x20;   retained fast linear rate >=0.01860477465101 at the uniform critical point.



These spectral bounds are algebraic reuse, not a new critical stochastic law.

A targeted dedup search found the exact pitchfork/barrier, failure of recursive

localized splitting and finite-N parity nonlumpability, but no completed

actual-generator N^(-1/4)/N^(1/2) uniform-critical path theorem in those inputs.

The execution agent must stop any duplicate task if a prior theorem is found.



[UF_DECISION.md]\(UF_DECISION.md) selects **\*\*SYMMETRIC_START_CRITICAL_FLUCTUATIONS\*\***:

derive a quartic confining collective path law from the same generator near

that existing instability, with microscopic noise and dangerous fast-coupling

terms paid, then distinguish local dynamical limiting equilibrium from the

full finite-N Gibbs law. The proposed scaling/SDE remain **\*\*unexecuted targets\*\***.



This is not reopening the failed recursive parity-bit/capacity programme,

and is not a new spatial incidence, physical clock or selector theorem.

An iid-uniform initial law is a stated statistical initial premise, not a

derived cosmological initial state. The critical gain family remains supplied

mathematical control, not a natural gain-selection principle.



Independent A7/kinetics source, units/locality/conserved physical energy and

empirical interfaces remain missing. No QM/GR/SM, physical particle, QW-2191,

legacy-role transfer, B4, FIN-M0, task335 or ToE closure is admitted.
